interface FileEntry {
    name: string;
    buffer: ArrayBuffer;
}
interface IDecryptFileParams {
    onName?(filename: string): string;
    onContent?(text: string, filename: string): string;
    ungzip?(file: Uint8Array): any;
    untar?(file: ArrayBuffer): Promise<FileEntry[]>;
    gzip?(files: any): any;
    zip?(files: any): any;
    tar?(files: any): any;
    useZip?: boolean;
    mineType?: string;
}

declare function useLicense(license: string | string[], _fileBuffer?: ArrayBuffer, _fileParams?: IDecryptFileParams): Promise<any>;

export { useLicense };

// license: z899v7Pw
