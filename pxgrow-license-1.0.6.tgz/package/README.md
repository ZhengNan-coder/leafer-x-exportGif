# @pxgrow/license

## 📦 安装方式（本地安装）

本插件不发布于公开 NPM 仓库，仅授权用户可通过本地 `.tgz` 文件安装使用。

### 第一步：获取插件包

购买后，你将获得一个名为 `pxgrow-license-1.0.0.tgz` 的压缩安装包。

将该文件放置在你的项目根目录下（或任意可访问路径）。

---

### 第二步：本地安装命令

根据你使用的包管理器，选择以下方式之一：

#### 使用 pnpm

```bash
pnpm add ./pxgrow-license-1.0.0.tgz
```

#### 使用 npm

```bash
npm install ./pxgrow-license-1.0.0.tgz
```

#### 使用 yarn

```bash
yarn add ./pxgrow-license-1.0.0.tgz
```

#### 使用 bun

```bash
bun add ./pxgrow-license-1.0.0.tgz
```

### 📌 注意事项

- 确保路径正确（如 `./pxgrow-license-1.0.0.tgz`），并在安装命令中包含文件扩展名。
- `.tgz` 安装包建议不要上传至 Git 仓库，可放入 `.npmrc` 中配置私有源或忽略。
- 若有安装或授权问题，请联系官方支持邮箱。
