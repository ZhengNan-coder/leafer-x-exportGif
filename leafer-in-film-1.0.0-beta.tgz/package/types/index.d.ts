import { IFilmInputData, IFilm, IFilmData, ILeafPaint, IFilmDecoder, IMultimediaType, IFilmFrame, ICanvasContext2D, IPointData, IBooleanMap, IFilmFileType, ILeaf, IFilmPlayOptions } from '@leafer-ui/interface';
import { Image, ImageData } from '@leafer-ui/draw';

declare class Film<TInputData = IFilmInputData> extends Image<TInputData> implements IFilm {
    get __tag(): string;
    __: IFilmData;
    get playerOptions(): ILeafPaint;
    get decoder(): IFilmDecoder;
    togglePlay(): void;
    play(): void;
    pause(): void;
    stop(): void;
    seekFrame(frameIndex: number): void;
}

declare class FilmData extends ImageData {
    get __urlType(): IMultimediaType;
}

interface IFilmDecoderMap {
    [name: string]: {
        Decoder: any;
        force?: boolean;
    };
}
declare class FilmDecoder implements IFilmDecoder {
    width: number;
    height: number;
    total: number;
    loop: number;
    frames: IFilmFrame[];
    decodedIndex: number;
    atlas?: any;
    atlasContext?: ICanvasContext2D;
    atlasGrid?: IPointData;
    decoder: ImageDecoder;
    bufferCanvas?: any;
    bufferContext?: ICanvasContext2D;
    static decoderMap: IFilmDecoderMap;
    static supportMap: IBooleanMap;
    static maxAtlasSize: number;
    static register(type: IFilmFileType, Decoder: any, force?: boolean): void;
    static canUse(mimeType: string): Promise<boolean>;
    createAtlas(): void;
    decodeHeader(data: ArrayBuffer, type: string): Promise<void>;
    decodeFrame(frameIndex: number): Promise<IFilmFrame>;
    decodeOneFrame(frameIndex: number): Promise<IFilmFrame>;
    mergeFrame(frameIndex: number, destoryFrameImage?: boolean): void;
    render(canvas: ICanvasContext2D, x: number, y: number, width: number, height: number, leaf: ILeaf, playOptions: IFilmPlayOptions, _imageScaleX: number, _imageScaleY: number): void;
    private renderFrame;
    destoryFrame(frameIndex: number, deleteIndex?: boolean): void;
    destoryFrameImage(frame: IFilmFrame): void;
    destroyDecoder(): void;
    close(): void;
}

export { Film, FilmData, FilmDecoder };

// license: zA8w27T9
